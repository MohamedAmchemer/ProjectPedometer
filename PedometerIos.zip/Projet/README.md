More about project you can find at https://brightinventions.pl/blog/coremotion-pedometer-swift/
